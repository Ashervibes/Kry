#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <windows.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#include <time.h>
#include <process.h>

#pragma comment(lib,"ws2_32.lib")

#define MAX_VARS 4096
#define MAX_LINES 8192
#define MAX_STR 2048
#define MAX_THREADS 64

typedef enum { NUM, STR, SOCK, PID } VarType;

typedef struct {
    char name[64];
    VarType type;
    union {
        double num;
        char str[MAX_STR];
        SOCKET sock;
        HANDLE pid;
    } value;
} Variable;

Variable vars[MAX_VARS];
int var_count = 0;

HANDLE threads[MAX_THREADS];
int thread_count = 0;

// ------------------- Function Prototype -------------------
void execute_line(char* line);  // <<< FIX: prototype for thread_func

// ------------------- Variables -------------------
Variable* get_var(const char* name){
    for(int i=0;i<var_count;i++){
        if(strcmp(vars[i].name,name)==0) return &vars[i];
    }
    return NULL;
}

void set_var(const char* name, Variable v){
    Variable* existing = get_var(name);
    if(existing) *existing = v;
    else { vars[var_count++] = v; strncpy(vars[var_count-1].name,name,63); }
}

// ------------------- Evaluation -------------------
Variable eval_expr(const char* expr){
    Variable v;
    if(!expr){ v.type=STR; v.value.str[0]=0; return v; }
    if(strncmp(expr,"!! `",4)==0){
        v.type=STR; strncpy(v.value.str,expr+4,MAX_STR-1);
        char* end = strchr(v.value.str,'`'); if(end) *end=0;
    } else if(strncmp(expr,"!!?",3)==0){
        v.type=NUM; v.value.num = (rand() % ((int)atof(expr+3)+1));
    } else if(strncmp(expr,"!!",2)==0){
        v.type=NUM; v.value.num=atof(expr+2);
    } else if(strcmp(expr,"$$")==0){
        char buf[MAX_STR]; fgets(buf,MAX_STR,stdin); buf[strcspn(buf,"\n")]=0;
        v.type=STR; strncpy(v.value.str,buf,MAX_STR-1);
    } else {
        Variable* existing = get_var(expr);
        if(existing) v=*existing;
        else { v.type=STR; strncpy(v.value.str,expr,MAX_STR-1); }
    }
    return v;
}

// ------------------- File I/O -------------------
Variable file_read_var(const char* filename){
    FILE* f = fopen(filename,"r");
    Variable v; v.type=STR;
    if(!f){ v.value.str[0]=0; return v; }
    fread(v.value.str,1,MAX_STR-1,f);
    v.value.str[MAX_STR-1]=0;
    fclose(f);
    return v;
}

void file_write_var(const char* filename, Variable* v){
    FILE* f = fopen(filename,"w");
    if(!f) return;
    if(v->type==STR) fprintf(f,"%s",v->value.str);
    fclose(f);
}

// ------------------- Networking -------------------
void exec_network(char* line){
    if(strncmp(line,"@@ tcp_connect",14)==0){
        char ip[64], varname[64]; int port;
        sscanf(line+14,"%s %d %s",ip,&port,varname);
        WSADATA wsa;
        WSAStartup(MAKEWORD(2,2),&wsa);
        SOCKET s = socket(AF_INET,SOCK_STREAM,0);
        struct sockaddr_in addr; addr.sin_family=AF_INET; addr.sin_port=htons(port);
        addr.sin_addr.s_addr = inet_addr(ip); // Windows inet_addr
        if(connect(s,(struct sockaddr*)&addr,sizeof(addr))<0) printf("TCP connect failed\n");
        Variable v; v.type=SOCK; v.value.sock=s; strncpy(v.name,varname,63); set_var(varname,v);
    } else if(strncmp(line,"@@ tcp_send",11)==0){
        char varname[64]; sscanf(line+11,"%s",varname);
        Variable* v = get_var(varname);
        if(v && v->type==STR){
            SOCKET sock = 0;
            Variable* sck = get_var(varname); if(sck && sck->type==SOCK) sock = sck->value.sock;
            send(sock,v->value.str,(int)strlen(v->value.str),0);
        }
    } else if(strncmp(line,"@@ tcp_recv",11)==0){
        char varname[64], bufvar[64]; sscanf(line+11,"%s %s",varname,bufvar);
        Variable* v = get_var(varname);
        if(v && v->type==SOCK){
            char buf[MAX_STR]; int r = recv(v->value.sock,buf,MAX_STR-1,0);
            if(r>0){ buf[r]=0; Variable vb; vb.type=STR; strncpy(vb.value.str,buf,MAX_STR-1); strncpy(vb.name,bufvar,63); set_var(bufvar,vb); }
        }
    }
}

// ------------------- Threads -------------------
unsigned __stdcall thread_func(void* arg){
    char* code = (char*)arg;
    execute_line(code); // now known to compiler
    free(code);
    return 0;
}

void spawn_thread(char* code_line){
    if(thread_count>=MAX_THREADS) return;
    char* code = _strdup(code_line);
    threads[thread_count++] = (HANDLE)_beginthreadex(NULL,0,thread_func,code,0,NULL);
}

// ------------------- Line Execution -------------------
void execute_line(char* line){
    if(strncmp(line,"@@ tcp_",6)==0) exec_network(line);
    else if(strncmp(line,"@@ file_read",12)==0){
        char fname[128]; sscanf(line+12,"%s",fname);
        Variable v = file_read_var(fname); set_var(fname,v);
    } else if(strncmp(line,"@@ file_write",13)==0){
        char fname[128]; sscanf(line+13,"%s",fname);
        Variable* v = get_var(fname); if(v) file_write_var(fname,v);
    } else if(strncmp(line,"%%",2)==0){
        char varname[128]; sscanf(line+2,"%s",varname);
        Variable* v = get_var(varname);
        if(v){
            if(v->type==NUM) printf("%f\n",v->value.num);
            else if(v->type==STR) printf("%s\n",v->value.str);
        }
    } else if(strncmp(line,"@@ spawn_thread",15)==0){
        char code[1024]; sscanf(line+15,"%[^\n]",code);
        spawn_thread(code);
    } else if(strncmp(line,"@@",2)==0){
        char varname[64]; char expr[MAX_STR]; sscanf(line+2,"%s %[^\n]",varname,expr);
        Variable v = eval_expr(expr); strncpy(v.name,varname,63); set_var(varname,v);
    }
}

// ------------------- File Runner -------------------
void run_file(const char* path){
    FILE* f = fopen(path,"r");
    if(!f){ printf("Cannot open %s\n",path); return; }
    char line[1024];
    while(fgets(line,1024,f)){
        line[strcspn(line,"\n")]=0;
        execute_line(line);
    }
    fclose(f);
}

// ------------------- Main -------------------
int main(int argc,char** argv){
    srand((unsigned int)time(NULL));
    if(argc<2){ printf("Usage: xyzzl file.krf\n"); return 1; }
    run_file(argv[1]);
    for(int i=0;i<thread_count;i++) WaitForSingleObject(threads[i],INFINITE);
    return 0;
}
