# DLLs Required for Kry

Place the following Windows DLLs in this folder so the Kry interpreter can run:

- `libmpfr-4.dll`
- `libmingwex-0.dll`
- `mingwm10.dll`
- `libgmp-10.dll`
- `libisl-15.dll`
- `libatomic-1.dll`
- `libgomp-1.dll`
- `libobjc-4.dll`
- `libgfortran-3.dll`
- `libgcc_s_dw2-1.dll`
- `libquadmath-0.dll`
- `libssp-0.dll`
- `libstdc++-6.dll`
- `libmpc-3.dll`
- `pthreadGC-3.dll`
- `libgettextpo-0.dll`
- `libgettextsrc-0-18-3.dll`
- `libgettextlib-0-18-3.dll`
- `libintl-8.dll`
- `libexpat-1.dll`
- `libiconv-2.dll`
- `libcharset-1.dll`
- `zlib1.dll`
- `libltdl-7.dll`

---

💡 **Tip:** Make sure these DLLs are in the same folder as `kryint.exe` when you run the interpreter. You can use the provided `build.bat` to automatically copy them from this folder to the build directory.
