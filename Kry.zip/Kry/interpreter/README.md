# 🔹 Kry Interpreter

Kry is a versatile `.krf` scripting language interpreter in C.  
Supports file operations, TCP networking, threading, and custom scripts.  

📂 Folders: `src/` | `dlls/` | `examples/` | `tests/` | `scripts/`  

🚀 Run: `./kryint examples/demo.krf`
